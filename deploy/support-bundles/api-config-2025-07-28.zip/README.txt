Support bundle for HBL-340. Collected by marcus with scripts/collect_bundle.sh
